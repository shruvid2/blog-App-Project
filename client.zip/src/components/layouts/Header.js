import React from "react";
import styled from "styled-components";

import "../../App.css";
import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";

const Header = () => {
  return (
    <MainContainer>
      <h1>
       Humans of Pes 
        
      </h1>
      <div className="App">
     <AliceCarousel autoPlay autoPlayInterval="3000">
       
      <img src= "images/1.jpg" className="sliderimg" alt=""/>
      <img src=  "images/p2.png" className="sliderimg" alt=""/>
      <img src= "images/m2.jpg" className="sliderimg" alt=""/>
      <img src="images/p5.jpg" className="sliderimg" alt=""/>
    </AliceCarousel>
    </div>
     
    </MainContainer>
  );
};

export default Header;

// MAIN CONTEINER
const MainContainer = styled.header`
 
  

  h1 {
    transform: translate(-50%, -50%);
    color: black;
    font-size: 500%;
    font-weight: 300;
    position: absolute;
    top: 25%;
    left: 50%;
  }
`;
